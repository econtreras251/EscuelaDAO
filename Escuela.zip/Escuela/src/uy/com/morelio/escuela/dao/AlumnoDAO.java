package uy.com.morelio.escuela.dao;

import uy.com.morelio.escuela.modelo.Alumno;

public interface AlumnoDAO extends DAO<Alumno, Long>{
    

}
