package uy.com.morelio.escuela.dao;

import uy.com.morelio.escuela.modelo.Asignatura;

public interface AsignaturaDAO extends DAO<Asignatura, Long>{
    

}
