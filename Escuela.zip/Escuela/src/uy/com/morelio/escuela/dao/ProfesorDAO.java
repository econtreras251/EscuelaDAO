package uy.com.morelio.escuela.dao;

import uy.com.morelio.escuela.modelo.Profesor;

public interface ProfesorDAO extends DAO<Profesor, Long>{
    

}
